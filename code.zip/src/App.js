import logo from './logo.svg';
import './App.css';
import Play2Earn from './Component/Play2Earn/Play2Earn';
import Loading from './Component/Loading/Loading';
import CreateGame from './Component/CreateGame/CreateGame';
import InviteFriend from './Component/InviteFriend/InviteFriend';
function App() {
  return (
    <div className="App">
        <InviteFriend/> 
    </div>
  );
}

export default App;
